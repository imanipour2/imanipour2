# Enerfoam Commerce Identity Bridge v0.3.0

This is a self-contained, GPL-2.0-or-later WordPress plugin. It requires WooCommerce and Nextend Social Login.

Implements server-side mandatory plausible mobile on Classic and Store API checkout and normalizes Iranian mobile to +989...; enables WooCommerce page links to verified Enerfoam page IDs 1293 / 1307 / 1308 upon activation; displays Google alongside Woo email only after configured Nextend Google shortcode actually renders, and fills only empty billing name/email fields after login.

**Not implemented**: Google Cloud OAuth credentials, SMS/OTP, legal SIM identity verification, payment gateway. Phone formatting check is not evidence of ownership. No card owner matching. User must configure Google Nextend provider in WordPress after setting OAuth with exact redirect URI; secrets MUST NOT be included in code or a repository. Checkout gate must be tested with live Woo gateway/Store API before payments.

When deployed through the GitHub archive route, the PHP plugin is at archive root, recognized by WordPress as a plugin. Don't activate alongside earlier duplicate bridge.
