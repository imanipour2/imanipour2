<?php
/**
 * Plugin Name: Enerfoam Commerce Identity Bridge
 * Description: Adds Google sign-in beside WooCommerce account login when provider is configured; requires a mobile phone at checkout (classic and Store API), and prefills empty billing fields after Google sign-in.
 * Version: 0.3.0
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce, nextend-facebook-connect
 * Author: Tak Eista South (Enerfoam)
 * License: GPL-2.0-or-later
 * Text Domain: enerfoam-commerce-auth
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bind the already-created Enerfoam commerce pages to WooCommerce on activation. */
function efca_activate() {
    if ( ! function_exists( 'get_post_status' ) ) { return; }
    $pages = array(
        'woocommerce_myaccount_page_id' => 1293,
        'woocommerce_cart_page_id'      => 1307,
        'woocommerce_checkout_page_id'  => 1308,
    );
    foreach ( $pages as $option => $page_id ) {
        if ( 'publish' === get_post_status( $page_id ) ) {
            update_option( $option, $page_id );
        }
    }
    update_option( 'woocommerce_checkout_phone_field', 'required' );
}
register_activation_hook( __FILE__, 'efca_activate' );

function efca_normalize_digits( $value ) {
    $from = array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩' );
    $to   = array( '0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9' );
    return str_replace( $from, $to, (string) $value );
}

/**
 * Keep the most common Iranian formats; permit E.164 for overseas customers.
 * Valid formatting is not verification of SIM ownership. SMS OTP is separate.
 */
function efca_canonical_phone( $phone ) {
    $phone = preg_replace( '/[\s\-\(\)\.\x{200c}\x{200e}\x{200f}]+/u', '', efca_normalize_digits( $phone ) );
    if ( ! is_string( $phone ) ) { return ''; }
    if ( preg_match( '/^09\d{9}$/D', $phone ) ) { return '+98' . substr( $phone, 1 ); }
    if ( preg_match( '/^00989\d{9}$/D', $phone ) ) { return '+' . substr( $phone, 2 ); }
    if ( preg_match( '/^989\d{9}$/D', $phone ) ) { return '+' . $phone; }
    return $phone;
}

function efca_mobile_is_plausible( $phone, $country = 'IR' ) {
    $phone = efca_canonical_phone( $phone );
    if ( ! is_string( $phone ) || '' === $phone ) { return false; }
    if ( preg_match( '/^\+989\d{9}$/D', $phone ) ) { return true; }
    // For non-Iranian customers, E.164 is a syntax check, NOT carrier / mobile verification.
    return 'IR' !== strtoupper( (string) $country ) && (bool) preg_match( '/^\+[1-9]\d{7,14}$/D', $phone );
}

function efca_phone_message() {
    return 'برای ثبت سفارش، شماره موبایل معتبر وارد کنید (مثلاً ۰۹۱۲۳۴۵۶۷۸۹). در صورت ورود با گوگل نیز شماره موبایل الزامی است.';
}

function efca_require_phone_field( $fields ) {
    if ( isset( $fields['billing']['billing_phone'] ) && is_array( $fields['billing']['billing_phone'] ) ) {
        $fields['billing']['billing_phone']['required'] = true;
        $fields['billing']['billing_phone']['label'] = 'شماره موبایل';
        $fields['billing']['billing_phone']['type'] = 'tel';
        $fields['billing']['billing_phone']['autocomplete'] = 'tel';
        $fields['billing']['billing_phone']['placeholder'] = '۰۹۱۲۳۴۵۶۷۸۹';
        $fields['billing']['billing_phone']['priority'] = 35;
    }
    return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'efca_require_phone_field', 100 );
add_filter( 'default_option_woocommerce_checkout_phone_field', static function () { return 'required'; }, 100 );
add_filter( 'option_woocommerce_checkout_phone_field', static function () { return 'required'; }, 100 );

function efca_validate_classic_checkout( $data, $errors ) {
    $phone = isset( $data['billing_phone'] ) ? $data['billing_phone'] : '';
    $country = isset( $data['billing_country'] ) ? $data['billing_country'] : 'IR';
    if ( ! efca_mobile_is_plausible( $phone, $country ) ) {
        $errors->add( 'efca_billing_phone', efca_phone_message() );
    }
}
add_action( 'woocommerce_after_checkout_validation', 'efca_validate_classic_checkout', 10, 2 );

/** Canonicalize Iranian digits/spacing before saving the billing phone. */
add_filter( 'woocommerce_checkout_posted_data', static function ( $data ) {
    if ( isset( $data['billing_phone'] ) ) {
        $data['billing_phone'] = efca_canonical_phone( $data['billing_phone'] );
    }
    return $data;
}, 80 );

function efca_validate_store_api_checkout( $order, $request ) {
    if ( ! $request instanceof WP_REST_Request || strtoupper( $request->get_method() ) !== 'POST' ) {
        return;
    }
    $address = $request->get_param( 'billing_address' );
    $address = is_array( $address ) ? $address : array();
    $phone = isset( $address['phone'] ) ? $address['phone'] : '';
    $country = isset( $address['country'] ) ? $address['country'] : 'IR';
    if ( ! efca_mobile_is_plausible( $phone, $country ) ) {
        throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
            'enerfoam_mobile_required',
            efca_phone_message(),
            400
        );
    }
    if ( is_object( $order ) && method_exists( $order, 'set_billing_phone' ) ) {
        $order->set_billing_phone( efca_canonical_phone( $phone ) );
    }
}
add_action( 'woocommerce_store_api_checkout_update_order_from_request', 'efca_validate_store_api_checkout', 10, 2 );

/** Nextend Google button appears only if its provider really renders. */
function efca_google_button( $context = 'account' ) {
    if ( is_user_logged_in() || ! shortcode_exists( 'nextend_social_login' ) ) { return ''; }
    $redirect = ( 'checkout' === $context && function_exists( 'wc_get_checkout_url' ) )
        ? wc_get_checkout_url()
        : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' ) );
    if ( ! $redirect ) { $redirect = home_url( '/my-account/' ); }
    $html = do_shortcode( '[nextend_social_login provider="google" redirect="' . esc_url( $redirect ) . '"]' );
    if ( ! is_string( $html ) || ! trim( $html ) || false !== strpos( $html, '[nextend_social_login' ) || false === strpos( $html, '<' ) ) {
        return '';
    }
    return '<section class="efca-google" dir="rtl" lang="fa" aria-label="ورود با گوگل">'
        . '<p class="efca-or">یا</p>' . $html
        . '<p class="efca-note">با گوگل، نام و ایمیل شما در صورت ارائه تکمیل می‌شوند؛ شماره موبایل برای سفارش ضروری است و در صورت نبود، از شما درخواست می‌شود.</p></section>';
}
add_action( 'woocommerce_login_form_end', static function () { echo efca_google_button( 'account' ); }, 8 );
add_action( 'woocommerce_before_checkout_form', static function () {
    if ( function_exists( 'is_checkout' ) && is_checkout() ) { echo efca_google_button( 'checkout' ); }
}, 6 );

/** Copy into empty billing fields; never replace names edited by customer. */
function efca_on_google_authenticated( $user_id, $provider = null ) {
    $user_id = absint( $user_id );
    $user = get_userdata( $user_id );
    if ( ! $user ) { return; }
    $first = get_user_meta( $user_id, 'first_name', true );
    $last  = get_user_meta( $user_id, 'last_name', true );
    if ( is_object( $provider ) && method_exists( $provider, 'getAuthUserData' ) ) {
        if ( ! $first ) {
            $first = sanitize_text_field( (string) $provider->getAuthUserData( 'first_name' ) );
            if ( $first ) { update_user_meta( $user_id, 'first_name', $first ); }
        }
        if ( ! $last ) {
            $last = sanitize_text_field( (string) $provider->getAuthUserData( 'last_name' ) );
            if ( $last ) { update_user_meta( $user_id, 'last_name', $last ); }
        }
    }
    if ( $first && ! get_user_meta( $user_id, 'billing_first_name', true ) ) { update_user_meta( $user_id, 'billing_first_name', $first ); }
    if ( $last && ! get_user_meta( $user_id, 'billing_last_name', true ) ) { update_user_meta( $user_id, 'billing_last_name', $last ); }
    if ( is_email( $user->user_email ) && ! get_user_meta( $user_id, 'billing_email', true ) ) {
        update_user_meta( $user_id, 'billing_email', sanitize_email( $user->user_email ) );
    }
}
add_action( 'nsl_google_register_new_user', 'efca_on_google_authenticated', 50, 2 );
add_action( 'nsl_google_login', 'efca_on_google_authenticated', 50, 2 );
add_filter( 'nsl_google_auto_link_allowed', '__return_false', 99, 3 );

function efca_customer_role_for_new_google_user( $user_id ) {
    $user = new WP_User( absint( $user_id ) );
    if ( $user->exists() && array( 'subscriber' ) === $user->roles ) { $user->set_role( 'customer' ); }
}
add_action( 'nsl_google_register_new_user', 'efca_customer_role_for_new_google_user', 60 );

add_action( 'wp_enqueue_scripts', static function () {
    wp_register_style( 'efca-commerce', false, array(), '0.3.0' );
    wp_enqueue_style( 'efca-commerce' );
    wp_add_inline_style( 'efca-commerce', '.efca-google{direction:rtl;max-width:480px;border:1px solid #dbe3f1;border-radius:14px;padding:14px 16px;background:#fff;margin:20px 0;font-family:Vazirmatn,Tahoma,sans-serif}.efca-or{font-size:14px;text-align:center;color:#526171;margin:0 0 12px}.efca-note{font-size:12px;color:#536079;line-height:2;margin:12px 0 0}.efca-google a:focus-visible{outline:3px solid #4da2db;outline-offset:3px}' );
}, 20 );
